<script setup>

</script>

<template>
    <div>
        <slot/>
    </div>
</template>

<style scoped>

</style>